
# this file must be tested with run_test_file(...,set_env)

expect_equal(Sys.getenv("wa_babalooba"), "ba_la_bamboo")


