
# dotenv 1.0.3

* dotenv now does not error if the env file is empty (#5, @cimentadaj).

# dotenv 1.0.2

No user visible changes.

# dotenv 1.0.1

No user visible changes.

# dotenv 1.0.0

First release on CRAN.
