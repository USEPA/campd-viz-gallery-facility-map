## ---- results='asis', echo=FALSE----------------------------------------------
cat(paste(readLines("JuliaCall_in_RMarkdown.md")[-(1:4)], collapse = "\n"))

