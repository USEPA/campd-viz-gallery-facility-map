#include <cpp11.hpp>
using namespace cpp11;

[[cpp11::register]]
void fun() {}
