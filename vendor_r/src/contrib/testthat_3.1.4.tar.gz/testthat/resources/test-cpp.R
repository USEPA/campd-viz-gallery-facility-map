run_cpp_tests("%s")
