
expect_true(TRUE)
expect_true(TRUE)

exit_file(msg="snafubar")

expect_true(TRUE)
expect_true(TRUE)

