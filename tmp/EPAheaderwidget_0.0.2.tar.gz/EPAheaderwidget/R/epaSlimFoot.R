#' epaSlimNavInput Function
#'
#' Used in the UI functions of R Shiny apps
#'
#' @importFrom reactR createReactShinyInput
#' @importFrom htmltools htmlDependency tags
#'
#' @param inputId The id of the shiny object.
#' @param appVersion The application version
#' @param appPublished The application publish date
#'
#' @export
epaSlimFootInput <- function(inputId, appVersion = "v0.0.0", appPublished = "local") {
  reactR::createReactShinyInput(
    inputId,
    "epaSlimFoot",
    htmltools::htmlDependency(
      name = "epaSlimFoot-input",
      version = "1.0.0",
      src = "www/EPAheaderwidget/epaSlimFoot",
      package = "EPAheaderwidget",
      script = "epaSlimFoot.js"
    ),
    default = 0,
    configuration = list(appVersion=appVersion,appPublished=appPublished),
    htmltools::tags$div
  )
}
