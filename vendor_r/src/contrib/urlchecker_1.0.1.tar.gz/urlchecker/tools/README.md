The file `urltools.R` in this directory is copied from the SVN with the following

```
svn cat -r 80050 https://svn.r-project.org/R/trunk/src/library/tools/R/urltools.R > urltools.R
```

When you want to update it run the above command with the latest SVN revision number
