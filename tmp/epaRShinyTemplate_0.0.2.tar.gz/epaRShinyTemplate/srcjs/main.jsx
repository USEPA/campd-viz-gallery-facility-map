import initEpaHeadNavigation from './epaSlimHeader.jsx';
import initEpaFooter from './epaSlimFooter.jsx';
import '@trussworks/react-uswds/lib/index.css';
import "./index.scss";
import '@trussworks/react-uswds/lib/uswds.css';

initEpaHeadNavigation();
initEpaFooter();
