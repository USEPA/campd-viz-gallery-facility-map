navbarPage("Multiple [R] Terminals Demo",
  tabPanel("Terminal 1",
    editorUI("termone")
  ),
  tabPanel("Terminal 2",
    editorUI("termtwo")
  ),
  tabPanel("Terminal 3",
    editorUI("termthree")
  )
)
