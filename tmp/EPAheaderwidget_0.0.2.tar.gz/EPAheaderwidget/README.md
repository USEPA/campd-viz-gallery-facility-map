
# EPAheaderwidget

<!-- badges: start -->
<!-- badges: end -->

The goal of EPAheaderwidget is to supply users the EPA banner from the Easey Design System.

## Installation

You can install the development version of EPAheaderwidget from [GitHub](https://github.com/USEPA/EPAheaderwidget)

``` r
# install.packages("devtools")
devtools::install_github("USEPA/EPAheaderwidget")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(EPAheaderwidget)
## basic example code
ui <- div(

  # EPA navigation component
  epaSlimNavInput("epaNav",appEnvironment = "prod"),

  # App title ----
  titlePanel("Shiny Text"),
  
  # version and publish date component
  epaSlimFootInput("epaFoot", appVersion = "v0.0.0", appPublished = "local")
  
)

server <- function(input, output, session) {

}

shinyApp(ui, server)

```

