\dontrun{
getCranDescription(c("igraph", "ggplot2", "XML"),
  repos = c(CRAN = getOption("minicran.mran"))
)
}
